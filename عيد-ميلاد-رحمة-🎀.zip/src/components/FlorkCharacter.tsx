import React from 'react';
import { motion } from 'motion/react';

export type FlorkVariant =
  | 'gift'
  | 'party'
  | 'cake'
  | 'confused'
  | 'blushing_hearts'
  | 'shocked'
  | 'mustache_uncle'
  | 'holding_heart'
  | 'advice_book'
  | 'tangerine'
  | 'doctor'
  | 'celebration';

interface FlorkCharacterProps {
  variant: FlorkVariant;
  className?: string;
  candlesLit?: boolean;
}

export const FlorkCharacter: React.FC<FlorkCharacterProps> = ({
  variant,
  className = 'w-56 h-56 sm:w-64 sm:h-64',
  candlesLit = true,
}) => {
  return (
    <motion.div
      className={`relative flex items-center justify-center select-none ${className}`}
      initial={{ scale: 0.9, opacity: 0, y: 10 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
    >
      <svg
        viewBox="0 0 300 300"
        className="w-full h-full filter drop-shadow-md overflow-visible"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Base Flork Bean Body for standard poses */}
        {variant !== 'tangerine' && (
          <g>
            {/* Flork Head & Body (Bean shape) */}
            <path
              d="M 100 280 L 100 130 C 100 70, 200 70, 200 130 L 200 280"
              fill="#FFFFFF"
              stroke="#2C2C2C"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Blush cheeks */}
            <ellipse cx="120" cy="120" rx="9" ry="6" fill="#FFB6C1" opacity="0.8" />
            <ellipse cx="180" cy="120" rx="9" ry="6" fill="#FFB6C1" opacity="0.8" />
          </g>
        )}

        {/* --- VARIANT 1: GIFT --- */}
        {variant === 'gift' && (
          <g>
            {/* Eyes - Happy curved */}
            <path d="M 125 110 Q 132 103 138 110" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />
            <path d="M 162 110 Q 168 103 175 110" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />

            {/* Smile */}
            <path d="M 135 125 Q 150 138 165 125" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Arms holding gift */}
            <path d="M 105 160 Q 120 180 130 185" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 195 160 Q 180 180 170 185" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />

            {/* Gift Box */}
            <rect x="120" y="170" width="60" height="50" rx="8" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4.5" />
            <rect x="115" y="165" width="70" height="12" rx="4" fill="#FFB6C1" stroke="#2C2C2C" strokeWidth="4" />
            {/* Ribbon */}
            <line x1="150" y1="165" x2="150" y2="220" stroke="#FFF3B0" strokeWidth="6" />
            {/* Bow */}
            <path d="M 138 158 C 130 150, 145 145, 150 160 C 155 145, 170 150, 162 158 Z" fill="#FFF3B0" stroke="#2C2C2C" strokeWidth="3" />

            {/* Floating hearts above box */}
            <path d="M 85 90 C 85 80, 70 80, 70 92 C 70 102, 85 112, 85 112 C 85 112, 100 102, 100 92 C 100 80, 85 80, 85 90 Z" fill="#FF85A1" opacity="0.9" />
            <path d="M 215 95 C 215 87, 202 87, 202 96 C 202 104, 215 112, 215 112 C 215 112, 228 104, 228 96 C 228 87, 215 87, 215 95 Z" fill="#E2D4F9" opacity="0.9" />
          </g>
        )}

        {/* --- VARIANT 2: PARTY --- */}
        {variant === 'party' && (
          <g>
            {/* Party Hat */}
            <path d="M 130 72 L 150 15 L 170 72 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4.5" strokeLinejoin="round" />
            <line x1="135" y1="55" x2="165" y2="55" stroke="#FFF3B0" strokeWidth="5" />
            <line x1="140" y1="38" x2="160" y2="38" stroke="#BEE9E8" strokeWidth="5" />
            <polygon points="150,5 154,12 161,13 156,18 157,25 150,21 143,25 144,18 139,13 146,12" fill="#FFE45E" stroke="#2C2C2C" strokeWidth="2.5" />

            {/* Eyes - Dot eyes with sparkles */}
            <circle cx="132" cy="108" r="4.5" fill="#2C2C2C" />
            <circle cx="168" cy="108" r="4.5" fill="#2C2C2C" />

            {/* Winking or happy mouth */}
            <path d="M 140 122 Q 150 135 160 122" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Hands pointing up playfully */}
            <path d="M 100 150 Q 80 130 75 115" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 200 150 Q 220 130 225 115" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />

            {/* Floating question mark or sparkles */}
            <text x="230" y="100" fontSize="28" fontWeight="bold" fill="#FF85A1">👀</text>
          </g>
        )}

        {/* --- VARIANT 3: CAKE --- */}
        {variant === 'cake' && (
          <g>
            {/* Party Hat */}
            <path d="M 132 72 L 150 18 L 168 72 Z" fill="#E2D4F9" stroke="#2C2C2C" strokeWidth="4.5" strokeLinejoin="round" />
            <path d="M 138 52 C 145 50, 155 54, 162 52" stroke="#FF85A1" strokeWidth="4" fill="none" />
            <circle cx="150" cy="14" r="7" fill="#FFF3B0" stroke="#2C2C2C" strokeWidth="3" />

            {/* Eyes */}
            <circle cx="132" cy="108" r="5" fill="#2C2C2C" />
            <circle cx="168" cy="108" r="5" fill="#2C2C2C" />
            <circle cx="134" cy="106" r="1.5" fill="#FFFFFF" />
            <circle cx="170" cy="106" r="1.5" fill="#FFFFFF" />

            {/* Smile */}
            <path d="M 138 123 Q 150 136 162 123" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Left Arm holding Balloon string */}
            <path d="M 100 160 L 60 150 L 50 190" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            {/* Pink Balloon */}
            <path d="M 30 130 Q 30 70 55 70 Q 80 70 80 130 Q 80 150 55 150 Q 30 150 30 130 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4.5" />
            <path d="M 55 150 L 55 190" stroke="#2C2C2C" strokeWidth="3" fill="none" />
            <ellipse cx="45" cy="95" rx="5" ry="12" fill="#FFFFFF" opacity="0.6" transform="rotate(-20 45 95)" />

            {/* Right Arm holding Cake Tray */}
            <path d="M 195 160 Q 215 175 240 175" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />

            {/* Cake Tray */}
            <ellipse cx="230" cy="180" rx="45" ry="8" fill="#D2D6DC" stroke="#2C2C2C" strokeWidth="4" />

            {/* Cake Body */}
            <rect x="195" y="145" width="70" height="32" rx="6" fill="#FFF3B0" stroke="#2C2C2C" strokeWidth="4" />
            {/* Frosting layer */}
            <path d="M 195 145 Q 205 158 215 145 Q 225 158 235 145 Q 245 158 255 145 Q 265 158 265 145 L 265 135 L 195 135 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="3" />

            {/* Number 17 on Cake */}
            <text x="217" y="167" fontSize="16" fontWeight="bold" fontFamily="sans-serif" fill="#2C2C2C">17</text>

            {/* Single Big Candle */}
            <rect x="226" y="115" width="8" height="20" fill="#FFFFFF" stroke="#2C2C2C" strokeWidth="3" />
            {/* Candle Wick */}
            <line x1="230" y1="115" x2="230" y2="108" stroke="#2C2C2C" strokeWidth="3" />

            {/* Candle Flame */}
            {candlesLit && (
              <g className="animate-flame">
                <path d="M 230 108 Q 222 96 230 88 Q 238 96 230 108 Z" fill="#FFB703" stroke="#2C2C2C" strokeWidth="2" />
                <path d="M 230 105 Q 226 98 230 92 Q 234 98 230 105 Z" fill="#FF0000" />
              </g>
            )}
          </g>
        )}

        {/* --- VARIANT 4: CONFUSED --- */}
        {variant === 'confused' && (
          <g>
            {/* Question Mark floating */}
            <text x="210" y="80" fontSize="42" fontWeight="900" fill="#FF85A1" className="animate-bounce">؟</text>

            {/* Eye 1 - Squint / Circle */}
            <circle cx="130" cy="110" r="6" fill="#2C2C2C" />
            {/* Eye 2 - X or Spiral */}
            <path d="M 165 104 L 175 114 M 175 104 L 165 114" stroke="#2C2C2C" strokeWidth="4" strokeLinecap="round" />

            {/* Puzzled wavy mouth */}
            <path d="M 135 130 Q 145 120 155 130 Q 165 140 170 128" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Hand scratching head */}
            <path d="M 195 160 Q 215 130 185 85" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 105 160 Q 90 180 85 200" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
          </g>
        )}

        {/* --- VARIANT 5: BLUSHING HEARTS --- */}
        {variant === 'blushing_hearts' && (
          <g>
            {/* Party Hat Rainbow */}
            <path d="M 132 72 L 150 18 L 168 72 Z" fill="#BEE9E8" stroke="#2C2C2C" strokeWidth="4.5" strokeLinejoin="round" />
            <line x1="135" y1="52" x2="165" y2="52" stroke="#FF85A1" strokeWidth="4" />
            <line x1="140" y1="36" x2="160" y2="36" stroke="#FFF3B0" strokeWidth="4" />
            <circle cx="150" cy="14" r="6" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="3" />

            {/* Closed happy Eyes */}
            <path d="M 124 108 Q 132 98 140 108" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />
            <path d="M 160 108 Q 168 98 176 108" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />

            {/* Happy blushing smile */}
            <path d="M 138 122 Q 150 134 162 122" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Arms forming a HEART with hands in front of body */}
            <path d="M 105 160 Q 120 185 140 170" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 195 160 Q 180 185 160 170" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            {/* Heart shape formed by hands */}
            <path d="M 150 175 C 142 162, 128 168, 138 182 L 150 192 L 162 182 C 172 168, 158 162, 150 175 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="3" />

            {/* Hearts erupting around */}
            <path d="M 75 110 C 75 98, 60 98, 60 110 C 60 122, 75 132, 75 132 C 75 132, 90 122, 90 110 C 90 98, 75 98, 75 110 Z" fill="#FF85A1" className="animate-bounce" />
            <path d="M 225 110 C 225 98, 210 98, 210 110 C 210 122, 225 132, 225 132 C 225 132, 240 122, 240 110 C 240 98, 225 98, 225 110 Z" fill="#FF85A1" className="animate-bounce" style={{ animationDelay: '0.2s' }} />
          </g>
        )}

        {/* --- VARIANT 6: SHOCKED (MAMA) --- */}
        {variant === 'shocked' && (
          <g>
            {/* Shocked big round eyes */}
            <circle cx="130" cy="106" r="10" fill="#FFFFFF" stroke="#2C2C2C" strokeWidth="4" />
            <circle cx="130" cy="106" r="4" fill="#2C2C2C" />

            <circle cx="170" cy="106" r="10" fill="#FFFFFF" stroke="#2C2C2C" strokeWidth="4" />
            <circle cx="170" cy="106" r="4" fill="#2C2C2C" />

            {/* O-shaped mouth */}
            <ellipse cx="150" cy="130" rx="8" ry="12" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4" />

            {/* Hands on cheeks in shock */}
            <path d="M 105 160 Q 110 125 115 120" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />
            <path d="M 195 160 Q 190 125 185 120" stroke="#2C2C2C" strokeWidth="5" fill="none" strokeLinecap="round" />

            {/* Shock lines around head */}
            <line x1="90" y1="80" x2="75" y2="70" stroke="#FF85A1" strokeWidth="4" strokeLinecap="round" />
            <line x1="210" y1="80" x2="225" y2="70" stroke="#FF85A1" strokeWidth="4" strokeLinecap="round" />
            <line x1="150" y1="55" x2="150" y2="40" stroke="#FF85A1" strokeWidth="4" strokeLinecap="round" />
          </g>
        )}

        {/* --- VARIANT 7: MUSTACHE UNCLE (عم فتحي) --- */}
        {variant === 'mustache_uncle' && (
          <g>
            {/* Flat cap / Uncle Hat */}
            <path d="M 110 75 Q 150 55 190 75 L 205 85 L 95 85 Z" fill="#6C757D" stroke="#2C2C2C" strokeWidth="4.5" />
            <line x1="90" y1="85" x2="210" y2="85" stroke="#2C2C2C" strokeWidth="5" strokeLinecap="round" />

            {/* Serious / Funny squint eyes */}
            <line x1="122" y1="102" x2="138" y2="102" stroke="#2C2C2C" strokeWidth="5" strokeLinecap="round" />
            <line x1="162" y1="102" x2="178" y2="102" stroke="#2C2C2C" strokeWidth="5" strokeLinecap="round" />

            {/* Big Classic Egyptian Black Mustache */}
            <path d="M 150 122 C 135 112, 110 120, 115 130 C 120 138, 140 128, 150 125 C 160 128, 180 138, 185 130 C 190 120, 165 112, 150 122 Z" fill="#2C2C2C" />

            {/* Arm folded like an old uncle */}
            <path d="M 105 160 L 195 160" stroke="#2C2C2C" strokeWidth="6" strokeLinecap="round" />
          </g>
        )}

        {/* --- VARIANT 8: HOLDING HEART --- */}
        {variant === 'holding_heart' && (
          <g>
            {/* Tender eyes */}
            <path d="M 125 106 Q 132 100 138 106" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />
            <path d="M 162 106 Q 168 100 175 106" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Sweet smile */}
            <path d="M 140 120 Q 150 128 160 120" stroke="#2C2C2C" strokeWidth="3.5" fill="none" strokeLinecap="round" />

            {/* Arms holding a glossy big Red Heart */}
            <path d="M 105 160 Q 125 165 135 165" stroke="#2C2C2C" strokeWidth="5" fill="none" fillRule="evenodd" />
            <path d="M 195 160 Q 175 165 165 165" stroke="#2C2C2C" strokeWidth="5" fill="none" fillRule="evenodd" />

            {/* Shiny Big Heart */}
            <path d="M 150 145 C 130 125, 105 140, 125 165 L 150 190 L 175 165 C 195 140, 170 125, 150 145 Z" fill="#E63946" stroke="#2C2C2C" strokeWidth="4" />
            <path d="M 132 145 C 130 148, 132 153, 138 153" stroke="#FFFFFF" strokeWidth="3" fill="none" strokeLinecap="round" />
          </g>
        )}

        {/* --- VARIANT 9: ADVICE BOOK --- */}
        {variant === 'advice_book' && (
          <g>
            {/* Smart glasses on Flork */}
            <circle cx="132" cy="108" r="12" fill="none" stroke="#2C2C2C" strokeWidth="4" />
            <circle cx="168" cy="108" r="12" fill="none" stroke="#2C2C2C" strokeWidth="4" />
            <line x1="144" y1="108" x2="156" y2="108" stroke="#2C2C2C" strokeWidth="4" />

            {/* Gentle smile */}
            <path d="M 140 126 Q 150 134 160 126" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Hands holding open book */}
            <path d="M 105 160 Q 120 175 125 175" stroke="#2C2C2C" strokeWidth="5" fill="none" />
            <path d="M 195 160 Q 180 175 175 175" stroke="#2C2C2C" strokeWidth="5" fill="none" />

            {/* Book Pages */}
            <path d="M 110 160 L 150 170 L 190 160 L 190 200 L 150 210 L 110 200 Z" fill="#FFF3B0" stroke="#2C2C2C" strokeWidth="4.5" />
            <line x1="150" y1="170" x2="150" y2="210" stroke="#2C2C2C" strokeWidth="4" />
            {/* Text lines in book */}
            <line x1="120" y1="175" x2="142" y2="180" stroke="#2C2C2C" strokeWidth="3" strokeLinecap="round" />
            <line x1="120" y1="188" x2="142" y2="193" stroke="#2C2C2C" strokeWidth="3" strokeLinecap="round" />
            <line x1="158" y1="180" x2="180" y2="175" stroke="#2C2C2C" strokeWidth="3" strokeLinecap="round" />
            <line x1="158" y1="193" x2="180" y2="188" stroke="#2C2C2C" strokeWidth="3" strokeLinecap="round" />
          </g>
        )}

        {/* --- VARIANT 10: TANGERINE (اليوسفي بتاعك) --- */}
        {variant === 'tangerine' && (
          <g className="animate-bounce">
            {/* Bouncing Cute Tangerine Body */}
            <circle cx="150" cy="160" r="75" fill="#FF8C00" stroke="#2C2C2C" strokeWidth="5" />
            {/* Tangerine texture dots */}
            <circle cx="120" cy="130" r="2" fill="#FFA500" />
            <circle cx="180" cy="140" r="2" fill="#FFA500" />
            <circle cx="140" cy="190" r="2" fill="#FFA500" />
            <circle cx="165" cy="200" r="2" fill="#FFA500" />

            {/* Leaf on top */}
            <path d="M 150 85 Q 175 60 190 75 Q 165 100 150 85 Z" fill="#2A9D8F" stroke="#2C2C2C" strokeWidth="4" />
            <path d="M 150 85 Q 130 65 120 78 Q 140 95 150 85 Z" fill="#2A9D8F" stroke="#2C2C2C" strokeWidth="3.5" />

            {/* Cute Flork Face on Tangerine */}
            <circle cx="128" cy="150" r="6" fill="#2C2C2C" />
            <circle cx="172" cy="150" r="6" fill="#2C2C2C" />
            <circle cx="130" cy="148" r="2" fill="#FFFFFF" />
            <circle cx="174" cy="148" r="2" fill="#FFFFFF" />

            {/* Cute Tongue Out Smile */}
            <path d="M 135 168 Q 150 185 165 168" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />
            <path d="M 144 174 Q 150 185 156 174" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="2" />

            {/* Pink cheeks */}
            <ellipse cx="115" cy="162" rx="8" ry="5" fill="#FFB6C1" opacity="0.8" />
            <ellipse cx="185" cy="162" rx="8" ry="5" fill="#FFB6C1" opacity="0.8" />
          </g>
        )}

        {/* --- VARIANT 11: DOCTOR (الدكتورة) --- */}
        {variant === 'doctor' && (
          <g>
            {/* White Doctor Coat */}
            <path d="M 100 180 L 125 150 L 150 185 L 175 150 L 200 180 L 200 280 L 100 280 Z" fill="#F8F9FA" stroke="#2C2C2C" strokeWidth="4.5" />

            {/* Stethoscope around neck */}
            <path d="M 125 150 Q 110 180 135 210 Q 150 225 165 210 Q 190 180 175 150" stroke="#2A9D8F" strokeWidth="5" fill="none" strokeLinecap="round" />
            {/* Stethoscope bell */}
            <circle cx="150" cy="225" r="9" fill="#D2D6DC" stroke="#2C2C2C" strokeWidth="3" />

            {/* Proud cute eyes */}
            <circle cx="132" cy="108" r="5" fill="#2C2C2C" />
            <circle cx="168" cy="108" r="5" fill="#2C2C2C" />
            <circle cx="134" cy="106" r="1.5" fill="#FFFFFF" />
            <circle cx="170" cy="106" r="1.5" fill="#FFFFFF" />

            {/* Confident happy smile */}
            <path d="M 136 122 Q 150 136 164 122" stroke="#2C2C2C" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Sparkles around head */}
            <text x="70" y="90" fontSize="24">✨</text>
            <text x="210" y="90" fontSize="24">🩺</text>
          </g>
        )}

        {/* --- VARIANT 12: CELEBRATION --- */}
        {variant === 'celebration' && (
          <g>
            {/* Party Hat */}
            <path d="M 130 72 L 150 12 L 170 72 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4.5" strokeLinejoin="round" />
            <line x1="135" y1="52" x2="165" y2="52" stroke="#FFF3B0" strokeWidth="4" />
            <line x1="140" y1="35" x2="160" y2="35" stroke="#BEE9E8" strokeWidth="4" />
            <polygon points="150,2 153,8 160,9 155,14 156,20 150,17 144,20 145,14 140,9 147,8" fill="#FFE45E" stroke="#2C2C2C" strokeWidth="2.5" />

            {/* Super happy winking eyes */}
            <path d="M 125 108 Q 132 98 140 108" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />
            <path d="M 160 108 Q 168 98 176 108" stroke="#2C2C2C" strokeWidth="4.5" fill="none" strokeLinecap="round" />

            {/* Big open smile */}
            <path d="M 132 120 Q 150 142 168 120 Z" fill="#FF85A1" stroke="#2C2C2C" strokeWidth="4" />

            {/* Hands thrown up in celebration */}
            <path d="M 100 150 Q 75 110 65 95" stroke="#2C2C2C" strokeWidth="5.5" fill="none" strokeLinecap="round" />
            <path d="M 200 150 Q 225 110 235 95" stroke="#2C2C2C" strokeWidth="5.5" fill="none" strokeLinecap="round" />

            {/* Celebration elements */}
            <text x="45" y="80" fontSize="32">🎈</text>
            <text x="225" y="80" fontSize="32">🎉</text>
          </g>
        )}
      </svg>
    </motion.div>
  );
};
