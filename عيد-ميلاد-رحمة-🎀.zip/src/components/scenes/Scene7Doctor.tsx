import React from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';

interface Scene7Props {
  onNext: () => void;
}

export const Scene7Doctor: React.FC<Scene7Props> = ({ onNext }) => {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant="doctor" />
      </div>

      <div className="doodle-card p-6 mb-6 w-full bg-white/95 backdrop-blur-sm space-y-3.5 border-teal-300">
        <p className="text-base sm:text-lg font-cairo font-semibold text-slate-600">
          "و انا ك يوصف..."
        </p>

        <h2 className="text-2xl sm:text-3xl font-bold font-marhey text-teal-700 leading-relaxed">
          "عاوز أشوفك أكبر دكتورة في الدنيا 👀❤️"
        </h2>

        <p className="text-lg sm:text-xl font-cairo font-bold text-pink-600">
          "وصدقيني هتبقي قدها ❤️"
        </p>
      </div>

      <button
        onClick={() => {
          sound.playChime();
          onNext();
        }}
        className="doodle-btn px-8 py-4 bg-[#FF85A1] text-white font-marhey text-lg sm:text-xl font-bold hover:bg-[#FF6B8B] cursor-pointer w-full max-w-xs shadow-lg animate-pulse"
      >
        افتحي آخر حاجة 🎁
      </button>
    </motion.div>
  );
};
