import React from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';
import confetti from 'canvas-confetti';

interface Scene1Props {
  onNext: () => void;
}

export const Scene1Gift: React.FC<Scene1Props> = ({ onNext }) => {
  const handleOpenGift = () => {
    sound.playChime();
    sound.playConfettiSound();

    // Trigger gentle confetti
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#FF85A1', '#FFB6C1', '#FFF3B0', '#E2D4F9'],
    });

    onNext();
  };

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant="gift" />
      </div>

      <div className="doodle-card p-6 mb-6 w-full bg-white/95 backdrop-blur-sm">
        <h2 className="text-2xl sm:text-3xl font-bold font-marhey text-pink-600 mb-3 leading-relaxed">
          "استنيييي بس يا رحومتي 👀🎀"
        </h2>
        <p className="text-base sm:text-lg font-cairo font-semibold text-slate-700 leading-relaxed">
          "أنا محضرلك حاجة صغيرة كدا... 😂🎁"
        </p>
      </div>

      <button
        onClick={handleOpenGift}
        className="doodle-btn px-8 py-4 bg-[#FF85A1] text-white font-marhey text-lg sm:text-xl font-bold hover:bg-[#FF6B8B] cursor-pointer shadow-lg w-full max-w-xs flex items-center justify-center gap-2 group"
      >
        <span>افتحي الهدية 🎁</span>
      </button>
    </motion.div>
  );
};
