import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';
import confetti from 'canvas-confetti';

interface Scene8Props {
  onRestartAnimation?: () => void;
}

export const Scene8FinalMessage: React.FC<Scene8Props> = () => {
  const [animKey, setAnimKey] = useState(0);

  const rawLines = [
    "اعععععع 😭🎀 ،",
    "الكتكوتـة بتاعتي كبرت سنـة ،",
    "أحلى مـن تـم الـ 17 سنـة يعـم والله ،",
    "هااااابـي بيرث دااااااي يجلبييييي ،",
    "ويارب تكون سنـة كلها فرحة وتحقيق أحلام",
    "",
    "بجد وحشاااني أوي والله",
    "بس هنعمل إيـه بقاا ،",
    "",
    "المهم عاوزك تركزي جدا على اهدافك",
    "ومذاكرتك وصلاتك وكل حاجه كويسه",
    "عاوزك تركزي فيها ،",
    "",
    "وابعدي عن اي حد مش كويس",
    "وملكيش دعوه بحاجه",
    "ومتزعليش على حد ،",
    "",
    "نفسك ثم نفسك ثم اليوسفييي بتاعك😂🎀 ،",
    "",
    "خلي بالك من نفسك",
    "عاوز اشوفك أكبر دكتوره في الدنيا بجدد 👀❤️ ،",
    "",
    "بحبك كل سنة وانتي طيبة",
    "يٓ قلب يوووصف 🎀،",
  ];

  const triggerGrandConfetti = () => {
    sound.playChime();
    sound.playConfettiSound();

    const duration = 2.5 * 1000;
    const animationEnd = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#FF85A1', '#FFB6C1', '#FFF3B0', '#E2D4F9', '#BEE9E8'],
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#FF85A1', '#FFB6C1', '#FFF3B0', '#E2D4F9', '#BEE9E8'],
      });

      if (Date.now() < animationEnd) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  };

  useEffect(() => {
    // Initial delay before grand burst
    const timer = setTimeout(() => {
      triggerGrandConfetti();
    }, 800);

    return () => clearTimeout(timer);
  }, [animKey]);

  const handleReplay = () => {
    setAnimKey((prev) => prev + 1);
  };

  return (
    <motion.div
      key={animKey}
      className="flex flex-col items-center justify-center min-h-[85vh] px-4 py-6 text-center max-w-lg mx-auto relative z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <div className="mb-2 scale-90 sm:scale-100">
        <FlorkCharacter variant="celebration" />
      </div>

      {/* Main Birthday Banner */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, type: 'spring' }}
        className="mb-4"
      >
        <h1 className="text-2xl sm:text-4xl font-extrabold font-marhey text-[#FF85A1] drop-shadow-sm tracking-wide leading-tight">
          🎀 HAPPY BIRTHDAY RAHMA 🎀
        </h1>
        <p className="text-lg sm:text-2xl font-bold font-marhey text-purple-700 mt-1">
          كل سنة وانتي طيبة يا قلب يووووسف 🎀
        </p>
      </motion.div>

      {/* Animated Letter Body */}
      <div className="doodle-card p-6 sm:p-8 mb-6 w-full bg-white/95 backdrop-blur-md shadow-xl border-pink-300 text-right font-cairo">
        <div className="space-y-1.5 text-base sm:text-lg text-slate-800 font-bold leading-relaxed">
          {rawLines.map((line, idx) => {
            if (line === "") {
              return <div key={idx} className="h-3" />;
            }
            return (
              <motion.p
                key={idx}
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + idx * 0.08 }}
                className={
                  line.includes("يٓ قلب يوووصف") || line.includes("بحبك كل سنة")
                    ? "text-pink-600 font-extrabold text-lg sm:text-xl font-marhey text-center pt-2"
                    : line.includes("HAPPY BIRTHDAY")
                    ? "text-pink-500 font-bold"
                    : ""
                }
              >
                {line}
              </motion.p>
            );
          })}
        </div>

        {/* Closing Note */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: rawLines.length * 0.08 + 0.8 }}
          className="mt-6 pt-4 border-t-2 border-dashed border-pink-200 text-center"
        >
          <p className="text-base sm:text-lg font-marhey font-bold text-pink-600 leading-relaxed">
            "خلصنااا ...<br />
            بس يوم عيد ميلادك هو أحلى حاجة حصلت السنهه ديي 🎀❤️"
          </p>
        </motion.div>
      </div>

      {/* Replay Button */}
      <motion.button
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: rawLines.length * 0.08 + 1.2 }}
        onClick={handleReplay}
        className="doodle-btn px-8 py-3.5 bg-[#FF85A1] text-white font-marhey text-lg font-bold hover:bg-[#FF6B8B] cursor-pointer w-full max-w-xs shadow-lg mb-8"
      >
        لكييي تباا 😂🎀
      </motion.button>
    </motion.div>
  );
};
