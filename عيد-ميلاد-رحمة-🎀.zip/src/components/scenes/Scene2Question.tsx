import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';
import confetti from 'canvas-confetti';

interface Scene2Props {
  onNext: () => void;
}

export const Scene2Question: React.FC<Scene2Props> = ({ onNext }) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  const handleStep1 = () => {
    sound.playPop();
    setStep(2);
  };

  const handleStep2 = () => {
    sound.playChime();
    sound.playConfettiSound();

    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.65 },
      colors: ['#FF85A1', '#BEE9E8', '#FFF3B0', '#FFB6C1'],
    });

    setStep(3);
  };

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant={step === 3 ? 'blushing_hearts' : 'party'} />
      </div>

      <div className="doodle-card p-6 mb-6 w-full bg-white/95 backdrop-blur-sm min-h-[140px] flex items-center justify-center">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-2"
            >
              <h2 className="text-xl sm:text-2xl font-bold font-marhey text-slate-800 leading-relaxed">
                "بصي بقا..."
              </h2>
              <p className="text-lg sm:text-xl font-cairo font-bold text-pink-600">
                "قبل أي حاجة، عندي سؤال مهم جدًا 👀"
              </p>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-2"
            >
              <p className="text-2xl sm:text-3xl font-bold font-marhey text-pink-600 leading-relaxed">
                "إنتي عارفة النهارده كام؟ 👀🎀"
              </p>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-2"
            >
              <h2 className="text-2xl sm:text-3xl font-bold font-marhey text-pink-600 leading-relaxed">
                "أيووووه 😂🎀"
              </h2>
              <p className="text-lg sm:text-xl font-cairo font-bold text-slate-700">
                "جايبلك كيكههه   ."
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="w-full max-w-xs flex flex-col gap-3 items-center">
        {step === 1 && (
          <button
            onClick={handleStep1}
            className="doodle-btn px-8 py-3.5 bg-[#FFF3B0] text-slate-800 font-marhey text-lg font-bold hover:bg-[#FFE875] cursor-pointer w-full"
          >
            إيه هو؟ 😂
          </button>
        )}

        {step === 2 && (
          <button
            onClick={handleStep2}
            className="doodle-btn px-8 py-3.5 bg-[#FF85A1] text-white font-marhey text-lg font-bold hover:bg-[#FF6B8B] cursor-pointer w-full animate-bounce"
          >
            21/8 ؟ 🎀
          </button>
        )}

        {step === 3 && (
          <button
            onClick={() => {
              sound.playPop();
              onNext();
            }}
            className="doodle-btn px-8 py-3.5 bg-[#C7F9CC] text-slate-800 font-marhey text-lg font-bold hover:bg-[#A1F0AD] cursor-pointer w-full"
          >
             وريني كدااا 😂🎀
          </button>
        )}
      </div>
    </motion.div>
  );
};
