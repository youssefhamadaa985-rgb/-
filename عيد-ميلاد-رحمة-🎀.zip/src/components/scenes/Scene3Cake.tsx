import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';

interface Scene3Props {
  onNext: () => void;
}

export const Scene3Cake: React.FC<Scene3Props> = ({ onNext }) => {
  const [candlesLit, setCandlesLit] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setCandlesLit(true);
      sound.playChime();
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2 relative">
        <FlorkCharacter variant="cake" candlesLit={candlesLit} />

        {/* Cake number overlay highlight */}
        <motion.div
          className="absolute -top-2 -right-2 bg-pink-100 border-2 border-[#2C2C2C] text-pink-600 px-3 py-1 rounded-full font-marhey font-bold text-sm shadow-[2px_2px_0px_#2C2C2C]"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.8, type: 'spring' }}
        >
          17 سنة! 🎂
        </motion.div>
      </div>

      <div className="doodle-card p-6 mb-6 w-full bg-white/95 backdrop-blur-sm space-y-3">
        <h2 className="text-xl sm:text-2xl font-bold font-marhey text-pink-600 leading-relaxed">
          "يعني رسميًا... الكتكوتة بتاعتي كبرت سنة 😭🎀"
        </h2>
        <p className="text-lg sm:text-xl font-cairo font-bold text-slate-800 leading-relaxed">
          "أحلى من تم الـ 17 سنة يعم والله 😂❤️"
        </p>
      </div>

      <button
        onClick={() => {
          sound.playPop();
          onNext();
        }}
        className="doodle-btn px-8 py-3.5 bg-[#FF85A1] text-white font-marhey text-lg font-bold hover:bg-[#FF6B8B] cursor-pointer w-full max-w-xs shadow-lg"
      >
        كملييي 🎀
      </button>
    </motion.div>
  );
};
