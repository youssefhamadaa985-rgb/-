import React from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';

interface Scene5Props {
  onNext: () => void;
}

export const Scene5Romantic: React.FC<Scene5Props> = ({ onNext }) => {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant="holding_heart" />
      </div>

      <div className="doodle-card p-6 mb-6 w-full bg-white/95 backdrop-blur-sm space-y-3.5 border-pink-400">
        <p className="text-base sm:text-lg font-cairo font-semibold text-slate-600">
          "بجد بقا بعيدًا عن الهزار..."
        </p>

        <h2 className="text-2xl sm:text-3xl font-bold font-marhey text-pink-600 leading-relaxed">
          "واحشني اوي يسطاا والله 🌍🌚"
        </h2>

        <p className="text-base sm:text-lg font-cairo font-bold text-slate-700 leading-relaxed">
        </p>
      </div>

      <button
        onClick={() => {
          sound.playChime();
          onNext();
        }}
        className="doodle-btn px-8 py-3.5 bg-[#FF85A1] text-white font-marhey text-lg font-bold hover:bg-[#FF6B8B] cursor-pointer w-full max-w-xs shadow-lg"
      >
          كمل ي فتحيي 👀
      </button>
    </motion.div>
  );
};
