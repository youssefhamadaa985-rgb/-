import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FlorkCharacter } from '../FlorkCharacter';
import { sound } from '../../audio/sound';

interface Scene6Props {
  onNext: () => void;
}

export const Scene6Advice: React.FC<Scene6Props> = ({ onNext }) => {
  const [showTangerine, setShowTangerine] = useState(false);

  const targets = [
    { icon: '🎯', text: 'أهدافك' },
    { icon: '📚', text: 'مذاكرتك' },
    { icon: '🙏', text: 'صلاتك' },
    { icon: '❤️', text: 'نفسك' },
    { icon: '🌸', text: 'وكل حاجة كويسة' },
  ];

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10 py-4"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant={showTangerine ? 'tangerine' : 'advice_book'} />
      </div>

      <div className="doodle-card p-5 mb-5 w-full bg-white/95 backdrop-blur-sm space-y-3">
        <h2 className="text-xl sm:text-2xl font-bold font-marhey text-slate-800 leading-relaxed">
          "عاوزك السنة دي تركزي جدًا علي دول 👇."
        </h2>

        {/* Animated Bullet Points */}
        <div className="grid grid-cols-1 gap-2 text-right font-cairo font-bold text-slate-700 bg-amber-50/60 p-3.5 rounded-xl border border-amber-200">
          {targets.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + index * 0.15 }}
              className="flex items-center gap-2 text-base sm:text-lg"
            >
              <span className="text-xl">{item.icon}</span>
              <span>{item.text}</span>
            </motion.div>
          ))}
        </div>

        <p className="text-sm sm:text-base font-cairo font-bold text-slate-600 leading-relaxed">
        </p>

        <p className="text-sm sm:text-base font-cairo font-bold text-pink-600">
      
        </p>

        {/* Cute Tangerine Reveal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2 }}
          className="pt-2 border-t border-pink-100"
        >
          <button
            onClick={() => {
              sound.playPop();
              setShowTangerine(true);
            }}
            className="text-base sm:text-lg font-marhey font-bold text-orange-600 cursor-pointer hover:underline focus:outline-none"
          >
      
          </button>
        </motion.div>
      </div>

      <button
        onClick={() => {
          sound.playPop();
          onNext();
        }}
        className="doodle-btn px-8 py-3.5 bg-[#FFF3B0] text-slate-900 font-marhey text-lg font-bold hover:bg-[#FFE875] cursor-pointer w-full max-w-xs shadow-md"
      >
        آخر حاجة ❤️
      </button>
    </motion.div>
  );
};
