import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FlorkCharacter, FlorkVariant } from '../FlorkCharacter';
import { sound } from '../../audio/sound';
import confetti from 'canvas-confetti';

interface Scene4Props {
  onNext: () => void;
}

export const Scene4Joke: React.FC<Scene4Props> = ({ onNext }) => {
  const [selectedNickname, setSelectedNickname] = useState<string | null>(null);
  const [characterVariant, setCharacterVariant] = useState<FlorkVariant>('confused');

  const handleSelect = (nickname: 'rahomty' | 'mama' | 'fathy') => {
    sound.playPop();

    if (nickname === 'rahomty') {
      setSelectedNickname('رحومتي 🎀');
      setCharacterVariant('blushing_hearts');
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.6 },
        colors: ['#FF85A1', '#FFB6C1'],
      });
    } else if (nickname === 'mama') {
      setSelectedNickname('ماما 😂');
      setCharacterVariant('shocked');
    } else {
      setSelectedNickname('عم فتحي 😂');
      setCharacterVariant('mustache_uncle');
    }
  };

  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-[82vh] px-4 text-center max-w-md mx-auto relative z-10"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-2">
        <FlorkCharacter variant={characterVariant} />
      </div>

      <div className="doodle-card p-5 mb-5 w-full bg-white/95 backdrop-blur-sm space-y-2">
        <h2 className="text-xl sm:text-2xl font-bold font-marhey text-[#2C2C2C] leading-relaxed">
          "بس استني... 17 سنة؟! 😭"
        </h2>
        <p className="text-base sm:text-lg font-cairo font-bold text-pink-600">
          "طب كدا أناديكي رحومتي ولا ماما ولا عم فتحي؟ 😂😂"
        </p>

        {selectedNickname && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mt-3 p-2.5 bg-pink-50 border-2 border-pink-300 rounded-xl font-marhey font-bold text-pink-700 text-lg"
          >
            "  اععععععع عم فتحيي اكيد  😂🎀"
          </motion.div>
        )}
      </div>

      {/* 3 Bubble Buttons */}
      <div className="w-full flex flex-col gap-2.5 mb-4">
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => handleSelect('rahomty')}
            className={`doodle-btn py-3 px-2 text-sm sm:text-base font-marhey font-bold cursor-pointer transition-all ${
              selectedNickname === 'رحومتي 🎀'
                ? 'bg-[#FF85A1] text-white scale-105'
                : 'bg-pink-100 text-pink-800 hover:bg-pink-200'
            }`}
          >
            رحومتي 🎀
          </button>

          <button
            onClick={() => handleSelect('mama')}
            className={`doodle-btn py-3 px-2 text-sm sm:text-base font-marhey font-bold cursor-pointer transition-all ${
              selectedNickname === 'ماما 😂'
                ? 'bg-[#E2D4F9] text-purple-900 scale-105'
                : 'bg-purple-100 text-purple-800 hover:bg-purple-200'
            }`}
          >
            ماما 😂
          </button>

          <button
            onClick={() => handleSelect('fathy')}
            className={`doodle-btn py-3 px-2 text-sm sm:text-base font-marhey font-bold cursor-pointer transition-all ${
              selectedNickname === 'عم فتحي 😂'
                ? 'bg-[#FFF3B0] text-slate-900 scale-105'
                : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
            }`}
          >
            عم فتحي 😂
          </button>
        </div>
      </div>

      <AnimatePresence>
        {selectedNickname && (
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => {
              sound.playPop();
              onNext();
            }}
            className="doodle-btn px-8 py-3.5 bg-[#C7F9CC] text-slate-800 font-marhey text-lg font-bold hover:bg-[#A1F0AD] cursor-pointer w-full max-w-xs shadow-md"
          >
            كملي يا ست الكل 👀
          </motion.button>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
