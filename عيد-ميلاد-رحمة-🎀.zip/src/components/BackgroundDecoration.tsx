import React from 'react';
import { motion } from 'motion/react';

export const BackgroundDecoration: React.FC = () => {
  // Generate static positions for floating hearts and sparkles
  const items = [
    { id: 1, symbol: '💖', left: '8%', top: '12%', delay: 0, scale: 1.1, dur: 6 },
    { id: 2, symbol: '✨', left: '85%', top: '15%', delay: 1, scale: 0.9, dur: 5 },
    { id: 3, symbol: '🌸', left: '15%', top: '75%', delay: 2, scale: 1.2, dur: 7 },
    { id: 4, symbol: '⭐', left: '88%', top: '80%', delay: 0.5, scale: 0.8, dur: 4.5 },
    { id: 5, symbol: '🎀', left: '5%', top: '45%', delay: 1.5, scale: 1, dur: 6.5 },
    { id: 6, symbol: '💖', left: '92%', top: '48%', delay: 2.5, scale: 0.9, dur: 5.5 },
    { id: 7, symbol: '✨', left: '48%', top: '8%', delay: 1.2, scale: 1.1, dur: 4 },
    { id: 8, symbol: '🎈', left: '80%', top: '30%', delay: 0.8, scale: 1, dur: 6.2 },
    { id: 9, symbol: '💕', left: '20%', top: '25%', delay: 1.8, scale: 0.85, dur: 5.8 },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none">
      {/* Gentle background pastel color orbs */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-pink-200/40 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute top-1/3 -right-24 w-80 h-80 bg-purple-200/35 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
      <div className="absolute -bottom-20 left-1/4 w-80 h-80 bg-amber-100/50 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '3s' }} />

      {/* Floating emojis and particles */}
      {items.map((item) => (
        <motion.div
          key={item.id}
          className="absolute text-xl sm:text-2xl opacity-70 filter drop-shadow-sm"
          style={{ left: item.left, top: item.top }}
          animate={{
            y: [-12, 12, -12],
            rotate: [-6, 6, -6],
            scale: [item.scale, item.scale * 1.15, item.scale],
          }}
          transition={{
            duration: item.dur,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: item.delay,
          }}
        >
          {item.symbol}
        </motion.div>
      ))}
    </div>
  );
};
