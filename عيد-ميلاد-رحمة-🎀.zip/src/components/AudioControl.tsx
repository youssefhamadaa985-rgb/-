import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { sound } from '../audio/sound';

export const AudioControl: React.FC = () => {
  const [muted, setMuted] = useState(sound.getMuted());

  const handleToggle = () => {
    const isMutedNow = sound.toggleMute();
    setMuted(isMutedNow);
  };

  return (
    <button
      onClick={handleToggle}
      aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
      className="fixed top-4 left-4 z-50 bg-white/90 backdrop-blur-md border-2 border-[#2C2C2C] p-2.5 rounded-full shadow-[2px_3px_0px_#2C2C2C] hover:scale-105 active:scale-95 transition-all text-slate-800 flex items-center gap-1.5 px-3 text-xs font-bold font-cairo cursor-pointer"
    >
      {muted ? (
        <>
          <VolumeX className="w-4 h-4 text-pink-500" />
          <span className="hidden sm:inline">الصوت مفيش</span>
        </>
      ) : (
        <>
          <Volume2 className="w-4 h-4 text-pink-600 animate-pulse" />
          <span className="hidden sm:inline">موسيقى كيوت 🎵</span>
        </>
      )}
    </button>
  );
};
