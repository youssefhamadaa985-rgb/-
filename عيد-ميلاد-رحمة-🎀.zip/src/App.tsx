import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AudioControl } from './components/AudioControl';
import { BackgroundDecoration } from './components/BackgroundDecoration';
import { sound } from './audio/sound';

import { Scene1Gift } from './components/scenes/Scene1Gift';
import { Scene2Question } from './components/scenes/Scene2Question';
import { Scene3Cake } from './components/scenes/Scene3Cake';
import { Scene4Joke } from './components/scenes/Scene4Joke';
import { Scene5Romantic } from './components/scenes/Scene5Romantic';
import { Scene6Advice } from './components/scenes/Scene6Advice';
import { Scene7Doctor } from './components/scenes/Scene7Doctor';
import { Scene8FinalMessage } from './components/scenes/Scene8FinalMessage';

export default function App() {
  const [currentScene, setCurrentScene] = useState<number>(1);

  const handleNext = () => {
    // Start ambient BGM on first user interaction if not playing
    sound.startBgm();

    if (currentScene < 8) {
      setCurrentScene((prev) => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FFFDF9] text-[#2C2C2C] relative overflow-x-hidden font-cairo flex flex-col justify-between py-2 sm:py-4 px-2 select-none">
      {/* Background ambient hearts and lights */}
      <BackgroundDecoration />

      {/* Header controls: Audio button & Scene progress indicator */}
      <header className="fixed top-0 left-0 right-0 z-40 p-3 sm:p-4 flex items-center justify-between pointer-events-none max-w-xl mx-auto">
        <div className="pointer-events-auto">
          <AudioControl />
        </div>

        {/* Scene progress indicator */}
        <div className="pointer-events-auto bg-white/90 backdrop-blur-md border-2 border-[#2C2C2C] px-3.5 py-1.5 rounded-full shadow-[2px_3px_0px_#2C2C2C] font-marhey font-bold text-xs sm:text-sm text-pink-600 flex items-center gap-1.5">
          <span>مرحلة {currentScene} من 8</span>
          <span className="text-pink-500">🎀</span>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 flex flex-col items-center justify-center pt-14 pb-6 z-10 w-full max-w-md mx-auto">
        <AnimatePresence mode="wait">
          {currentScene === 1 && (
            <motion.div key="s1" className="w-full">
              <Scene1Gift onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 2 && (
            <motion.div key="s2" className="w-full">
              <Scene2Question onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 3 && (
            <motion.div key="s3" className="w-full">
              <Scene3Cake onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 4 && (
            <motion.div key="s4" className="w-full">
              <Scene4Joke onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 5 && (
            <motion.div key="s5" className="w-full">
              <Scene5Romantic onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 6 && (
            <motion.div key="s6" className="w-full">
              <Scene6Advice onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 7 && (
            <motion.div key="s7" className="w-full">
              <Scene7Doctor onNext={handleNext} />
            </motion.div>
          )}

          {currentScene === 8 && (
            <motion.div key="s8" className="w-full">
              <Scene8FinalMessage />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Cute Footer */}
      <footer className="text-center text-xs font-marhey text-slate-400 py-2 relative z-10">
        صنع بحب لـ رحومتي 💖 21/8/2009
      </footer>
    </div>
  );
}
